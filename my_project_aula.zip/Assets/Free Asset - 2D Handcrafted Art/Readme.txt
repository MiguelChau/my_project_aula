Thanks for getting the Free Asset.
This asset contains a various selection of our other assets, so you can have a look of the quality of our assets

Hope you enjoy it!

Here is all the other 2D Handcrafted Art pacakges:
2D Snow Forest Pack - Handcrafted Art
2D Jungle Pack - Handcrafted Art
2D Desert Pack - Handcrafted Art
2D Lava Land Pack - Handcrafted Art
2D Microcosm Pack - Handcrafted Art
2D Under Water Pack - Handcrafted Art
2D Xeno Alien Planet Pack - Handcrafted Art
2D Graveyard Pack - Handcrafted Art
2D Military Pack - Handcrafted Art
2D Cyber City Pack - Handcrafted Art
Check them out here: https://www.assetstore.unity3d.com/#!/list/4573-2d-handcrafted-art-by-alien-nude


Making a platformer? We also made a mega bubndle, here we bundle of 7 of our packages with the top selling Corgi Engine. Check it out here: 
https://assetstore.unity.com/packages/templates/systems/corgi-engine-handcrafted-art-2d-platformer-mega-bundle-88444


Music in this free asset is provided by Matteo Bosi - Alchemy Studio
You are free to use these wav files in any of your pojects (games, video or whatever else, free or commercial) with the only requests to give him credits ("Music provided by Matteo Bosi - www.alchemystudio.it ") and send an email to Matteo writing him how and where you used his music. The music provided is royalty free and you can use it without any limitation.

matteo@alchemystudio.it
www.alchemystudio.it
https://assetstore.unity.com/publishers/755


PS: If you want to support us a little extra you can use our affiliatelink. Check out our list here: https://www.assetstore.unity3d.com/#!/list/4573-2d-handcrafted-art-by-alien-nude?aid=1101lGrn&pubref=FreeAsset